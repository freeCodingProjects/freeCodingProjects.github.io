package CubeLogic;

import java.util.Random;

import GUI.CubieType;

public class Cube {
	final private int faces = 6;
	private int size; //nxn cube
	private int cube[][][];
	public Cube(int size) {
		this.size = size; //maybe pass it in later
		cube = new int[faces][size][size];
		
		makeCube();
	}
	public Cube() {
		this(3); //default
		
	}
	
	public void makeCube() {
		for(int face = 0; face < faces; face++) {
			helperColorFace(cube[face], face);
		}
		
		
		cube[CubieType.TOP.getValue()][0][0]=7;
		/*cube[CubieType.FRONT.getValue()][2][2] = 6;
		
		
		cube[CubieType.TOP.getValue()][2][2] = 3;
		cube[CubieType.TOP.getValue()][0][2] = 3;
		//cube[CubieType.TOP.getValue()][1][2] = 3;
		
		
		cube[CubieType.RIGHT.getValue()][0][2] = 3;
		
		cube[CubieType.RIGHT.getValue()][0][1] = 4;
		cube[CubieType.BOTTOM.getValue()][0][0] = 3;
		cube[CubieType.BOTTOM.getValue()][1][0] = 3;
		cube[CubieType.LEFT.getValue()][2][2] = 3;
		cube[CubieType.BACK.getValue()][2][2] = 6;*/
	}
	
	/*
	 * prints cube just for testing now
	 */
	public void printCube() {
		for(int[][] face : cube) {
			for(int i = 0;i < face.length; i++) {
				for(int j =0;j < face[0].length; j++) {
					System.out.print(face[i][j]);
				}
				System.out.println();
			}
			System.out.println("");
		}
	}
	
	/*
	 * Colors a face of a cube a given color
	 */
	public void helperColorFace(int[][] face, int color) {
		for(int i =0;i<face.length;i++) {
			for(int j =0;j<face[0].length;j++) {
				face[i][j] = color;
			}
		}
	}
	
	
	
	
	/*
	 * Calls 30 random moves
	 */
	public void scramble() {
		Random random = new Random();
		for(int i = 0; i < 30; i++) {
			
		}
	}
	
	
	
	
	
	
	public void rotateTop(boolean clockwise) {
		//helperClockwise(0);
		
		
		
		
		
		
	}
	
	public void rotateBottom(boolean clockwise) {
	}
	
	
	/*
	 * I will not be writing the fast in place solution
	 * There is definitely reason to learn it
	 * But I don't think its as clear as the less space efficient solution
	 */
	public int[][] rotateFace(boolean clockwise, int face) {
		/*
		 * example:
		 * [1 2 3]
		 * [4 5 6]
		 * [7 8 9]
		 * 
		 * rotated face
		 * [7 4 1]
		 * [8 5 2]
		 * [9 6 3]
		 * 
		 */
		
		int[][] rotatedFace = new int[size][size];
		
		
		for(int i = 0; i<size; i++) {
			for(int j = 0; j<size; j++) {
				if (clockwise) {
					rotatedFace[i][j] = cube[face][size-j-1][i];
				}else {
					rotatedFace[i][j] = cube[face][j][size-i-1];
				}
				
			}
		}
		
		return rotatedFace;
	}
	
	
	public void rotateFront(boolean clockwise) {
		/*
		 * clockwise explanation
		 * rotate front face
		 * 
		 * 
		 * 
		 * 
		 * 
		 */
		
		int tmp[] = cube[CubieType.RIGHT.getValue()][0];
		//cube[CubieType.RIGHT.getValue()][0] = rotateFace(true, CubieType.TOP.getValue())[2];
		
		cube[CubieType.RIGHT.getValue()] = rotateFace(true, CubieType.RIGHT.getValue());
		
		
		
		
		
	}
	
	public void rotateBack(boolean clockwise) {
		
	}
	
	/*
	 * same as rotateLeft
	 */
	public void rotateRight(boolean clockwise) {
		/*
		cube[CubieType.FRONT.getValue()][2][0] = 6;
		cube[CubieType.TOP.getValue()][2][0] = 6;
		cube[CubieType.BOTTOM.getValue()][2][0] = 6;
		cube[CubieType.BACK.getValue()][2][0] = 6;
		cube[CubieType.RIGHT.getValue()][2][0] = 6;
		cube[CubieType.LEFT.getValue()][2][0] = 6;
		*/
		
		/*
		 * clockwise
		 * top = front
		 * front = bottom
		 * bottom = back
		 * back = top
		 */
		
		//I think this is the proper direction
		if (!clockwise) {
			cube[CubieType.RIGHT.getValue()] = rotateFace(false, CubieType.RIGHT.getValue());

			int tmp[] = cube[CubieType.TOP.getValue()][2];
			cube[CubieType.TOP.getValue()][2] = cube[CubieType.FRONT.getValue()][2];
			cube[CubieType.FRONT.getValue()][2] = cube[CubieType.BOTTOM.getValue()][2];
			cube[CubieType.BOTTOM.getValue()][2] = cube[CubieType.BACK.getValue()][2];
			cube[CubieType.BACK.getValue()][2] = tmp;
		}else {
			
			cube[CubieType.RIGHT.getValue()] = rotateFace(true, CubieType.RIGHT.getValue());
			int tmp[] = cube[CubieType.FRONT.getValue()][2];
			cube[CubieType.FRONT.getValue()][2] = cube[CubieType.TOP.getValue()][2];
			cube[CubieType.TOP.getValue()][2] = cube[CubieType.BACK.getValue()][2];
			cube[CubieType.BACK.getValue()][2] = cube[CubieType.BOTTOM.getValue()][2];
			cube[CubieType.BOTTOM.getValue()][2] = tmp;
		
			
			
		}
		
		
		
		
		
	}
	
	/*
	 * Same as rotateRight
	 */
	public void rotateLeft(boolean clockwise) {
		/*
		 * clockwise:
		 * top = front
		 * front = bottom
		 * bottom = back
		 * back = top
		 */
		
		if (!clockwise) {
			cube[CubieType.LEFT.getValue()] = rotateFace(true, CubieType.LEFT.getValue());

			int tmp[] = cube[CubieType.TOP.getValue()][0];
			cube[CubieType.TOP.getValue()][0] = cube[CubieType.FRONT.getValue()][0];
			cube[CubieType.FRONT.getValue()][0] = cube[CubieType.BOTTOM.getValue()][0];
			cube[CubieType.BOTTOM.getValue()][0] = cube[CubieType.BACK.getValue()][0];
			cube[CubieType.BACK.getValue()][0] = tmp;
		}else {
			
			cube[CubieType.LEFT.getValue()] = rotateFace(false, CubieType.LEFT.getValue());
			int tmp[] = cube[CubieType.FRONT.getValue()][0];
			cube[CubieType.FRONT.getValue()][0] = cube[CubieType.TOP.getValue()][0];
			cube[CubieType.TOP.getValue()][0] = cube[CubieType.BACK.getValue()][0];
			cube[CubieType.BACK.getValue()][0] = cube[CubieType.BOTTOM.getValue()][0];
			cube[CubieType.BOTTOM.getValue()][0] = tmp;
		
			
			
		}
	}
	
	
	
	public int[][][] export6b3by3cube(){
		//cube[0][1][0]=6;
		//rotateRight(true);
		
		return cube;
	}
}
