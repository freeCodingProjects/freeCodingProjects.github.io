package GUI;

import java.awt.Color;


import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import java.util.Collections;


import Student.Cube;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.KeyStroke;

 

public class CubeGUI extends JPanel implements MouseMotionListener{
	
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Point2D lastMousePos;

	private Cube cube;
	
	private ArrayList<Cubie> cubies;
	private ArrayList<Face> faces;
	private int[][][] faceColors;
	
	private int width;
	private int height;
	private JCheckBox toggleGrid;
	private boolean showGrid;
	public CubeGUI() {
		this.setBackground(Color.gray);
		width = 600;
		height = 600;
		
		this.setSize(width, height);
		showGrid=true;
		cube = new Cube();
		toggleGrid = new JCheckBox("Turn on/off Locations");
		toggleGrid.setSelected(true);
		
		this.add(toggleGrid);
		
		cubies = new ArrayList<Cubie>();
		faceColors = cube.export6b3by3cube();
		faces = new ArrayList<Face>();
		addCubies();
		initFaces();
		//testAdd();
		
		addMouseMotionListener(this);
		setupKeyBindings();
		lastMousePos = null;
		
		toggleGrid.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				showGrid = !showGrid;
				for(Face f : faces) {
					f.showGrid = showGrid;
				}
				repaint();
			}
			
		});
		
	}
	
	
	
	
	/*
	 * Setup keybindings
	 * bind actions to key characters
	 * i.e rotateRight clocwise to 'r', counterclockwise 'R'
	 */
	private void setupKeyBindings() {

		ActionMap actionMap;
		InputMap inputMap;
		
		actionMap = this.getActionMap();
		inputMap = this.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
		
		inputMap.put(KeyStroke.getKeyStroke('r'), "r");
		actionMap.put("r", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				cube.rotateRight(true);
				repaint();
			}
			
		});
		inputMap.put(KeyStroke.getKeyStroke('R'), "R");
		actionMap.put("R", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				cube.rotateRight(false);
				repaint();
			}
			
		});
		
		inputMap.put(KeyStroke.getKeyStroke('l'), "l");
		actionMap.put("l", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				cube.rotateLeft(true);
				repaint();
			}
			
		});
		inputMap.put(KeyStroke.getKeyStroke('L'), "L");
		actionMap.put("L", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				cube.rotateLeft(false);
				repaint();
			}
			
		});
		
		inputMap.put(KeyStroke.getKeyStroke('u'), "u");
		actionMap.put("u", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				cube.rotateTop(true);
				repaint();
			}
			
		});
		inputMap.put(KeyStroke.getKeyStroke('U'), "U");
		actionMap.put("U", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				cube.rotateTop(false);
				repaint();
			}
			
		});
		
		inputMap.put(KeyStroke.getKeyStroke('d'), "d");
		actionMap.put("d", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				cube.rotateBottom(true);
				repaint();
			}
			
		});
		inputMap.put(KeyStroke.getKeyStroke('D'), "D");
		actionMap.put("D", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				cube.rotateBottom(false);
				repaint();
			}
			
		});
		
		inputMap.put(KeyStroke.getKeyStroke('f'), "f");
		actionMap.put("f", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				cube.rotateFront(true);
				repaint();
			}
			
		});
		inputMap.put(KeyStroke.getKeyStroke('F'), "F");
		actionMap.put("F", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				cube.rotateFront(false);
				repaint();
			}
			
		});
		
		inputMap.put(KeyStroke.getKeyStroke('B'), "B");
		actionMap.put("B", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				cube.rotateBack(false);
				repaint();
			}
			
		});
		
	}
	
	
	
	/*
	 * The x,y,z are sort of ceremonious considering how they're transposed a lot lol
	 * 
	 * y is up and down, negative is up
	 * z is forward and back, negative is back
	 * x is right and left, negative is left
	 */
	public void addCubies() {
		double x = -1.2;
		for(double y = -1.2; y<=1.2; y+=1.2) {
			for(double z = -1.2; z<=1.2; z+=1.2) {

				cubies.add(new Cubie(new Point3D(x,y,z), CubieType.RIGHT,helperGetLoc(CubieType.RIGHT.getValue(),z,-y)));
				cubies.add(new Cubie(new Point3D(-x,y,z), CubieType.LEFT,helperGetLoc(CubieType.LEFT.getValue(),-z,-y)));
				
				cubies.add(new Cubie(new Point3D(z,x,y), CubieType.BOTTOM,helperGetLoc(CubieType.BOTTOM.getValue(),-z,y)));
				cubies.add(new Cubie(new Point3D(z,-x,y), CubieType.TOP,helperGetLoc(CubieType.TOP.getValue(),-z,-y)));

				cubies.add(new Cubie(new Point3D(y,z,-x), CubieType.BACK,helperGetLoc(CubieType.BACK.getValue(),-y,z)));
				cubies.add(new Cubie(new Point3D(y,z,x), CubieType.FRONT,helperGetLoc(CubieType.FRONT.getValue(),-y,-z)));
				
			}
		}
	}
	
	
	public void initFaces() {
		for (Cubie cubie : cubies) {
			faces.addAll(cubie.getFaces());
		}
	}
	
	
	
	private static int[] helperGetLoc(int face, double x, double y) {
		int[] loc = new int[] {face, convert(x), convert(y)};
		//System.out.println(face+" "+convert(x)+" "+convert(y));
		return loc;
	}private static int convert(double i) {
		if (i<0) {
			return 0;
		} else if(i == 0) {
			return 1;
		}
		return 2;
	}
	
	
	
	
	

		
		


		
	public void updateCubies() {
		//System.out.println("faef");
		faceColors = cube.export6b3by3cube();
		for(Cubie cubie : cubies) {
			cubie.updateColor(faceColors);
		}
	}
	
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		updateCubies();
		
		
		Collections.sort(faces);
		for(Face f : faces) {
			f.paintFace(g);
		}
		/*
		Collections.sort(cubies);
		for(Cubie c : cubies) {
			c.paintCubie(g);
		}*/
		
		
		
		
		
		//System.out.println(triangles.size());
		
		
	}
	

	
	

	

	

	
	//better than having them in there maybe?
	private double xdir;
	private double ydir;
	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
		
		if (lastMousePos!=null) {
			xdir = -(e.getX()-lastMousePos.x)*.02;
			ydir = (e.getY()-lastMousePos.y)*.02;
			
		}
		
		
		for(Cubie cubie : cubies) {
			cubie.rotateXY(ydir, xdir);
		}
		
		lastMousePos = new Point2D(e.getX(), e.getY());
		repaint();
	}


	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		lastMousePos = new Point2D(e.getX(), e.getY());
		//cube.rotateLeft(true);
		//repaint();
		
	}
	
	
	
	
	public static void main(String[] args) {
		JFrame frame = new JFrame();
		CubeGUI gui = new CubeGUI();
		frame.add(gui);
		frame.setVisible(true);
		frame.setSize(600, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
	}


	





	
}
