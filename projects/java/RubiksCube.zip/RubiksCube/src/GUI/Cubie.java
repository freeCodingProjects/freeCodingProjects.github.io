package GUI;


import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;


public class Cubie implements Comparable<Cubie>{
	private ArrayList<Point3D> points;
	private ArrayList<Face> faces;
	
	private int mainFaceColor;
	
	private Face frontFace, backFace, rightFace, leftFace, topFace, bottomFace;
	
	public Cubie(Point3D center) {
		this.mainFaceColor = 0;
		points = new ArrayList<Point3D>();
		
		points.add(new Point3D(0,0,0));
		points.add(new Point3D(1,0,0));
		points.add(new Point3D(1,1,0));
		points.add(new Point3D(0,1,0));
		
		points.add(new Point3D(0,0,1));
		points.add(new Point3D(1,0,1));
		points.add(new Point3D(1,1,1));
		points.add(new Point3D(0,1,1));
		
		
		//move to center
		for(Point3D p : points) {
			p.x-=center.x;
			p.y-=center.y;
			p.z-=center.z;
		}
		
		initFaces();
		
	}
	
	
	/*
	 * I cannot think of a better way to write a GUI that allows
	 * for failure in the structure of the code that exists
	 * 
	 * if edges, corners and centers were stored separately possibly idk
	 */
	public Cubie(Point3D center, CubieType cubieType) {
		this(center);
		
		//this is dumb, the proper face has to be
		//initialized to some non-black color for rendering to work
		//god im dumb
		switch (cubieType) {
			case FRONT:
				frontFace.setFaceColor(0);
				break;
			case BACK:
				backFace.setFaceColor(0);
				break;
			case RIGHT:
				rightFace.setFaceColor(0);
				break;
			case LEFT:
				leftFace.setFaceColor(0);
				break;
			case TOP:
				topFace.setFaceColor(0);
				break;
			case BOTTOM:
				bottomFace.setFaceColor(0);
				break;
			default:
				break;
			
			
		}
		
		
	}
	
	private int[] faceLoc;
	public Cubie(Point3D center, CubieType cubieType, int[] faceLoc) {
		this(center, cubieType);
		this.faceLoc = faceLoc;
		for(Face f : faces) {
			f.setFaceLoc(faceLoc);
		}
		
	}
	
	
	
	
	public void updateColor(int faceColors[][][]) {
		//null checking
		if (faceColors != null && faceColors.length==6 && faceColors[0].length==3 && faceColors[0][0].length==3) {
			for(Face f : faces) {
				if (f.faceColor != 6) {
					f.setFaceColor(faceColors[faceLoc[0]][faceLoc[1]][faceLoc[2]]);
				}
				
				
			}
		}
			
		
		
	}
	
	
	
	
	
	/*
	 * FRONT: BLUE
	 * BACK: GREEN
	 * RIGHT:YELLOW
	 * LEFT: WHITE
	 * TOP: ORANGE
	 * BOTTOM:RED
	 */
	public void initFaces() {
		faces = new ArrayList<Face>();
		//Orange
		rightFace = new Face(points.get(5),points.get(1),
							points.get(2),
							points.get(6),
							this.faceLoc
							
							
		);  
		
		//red
		leftFace = new Face(
				points.get(0),
				points.get(4),
				points.get(7),
				points.get(3),
				this.faceLoc
		);
		
		
		//blue
		frontFace = new Face(points.get(4),
				points.get(5),
				points.get(6),
				points.get(7),
				this.faceLoc);
		
		
		//yellow
		 backFace = new Face(
				points.get(1),
				points.get(0),
				points.get(3),
				points.get(2),
				this.faceLoc);
		
		
		//green
		bottomFace = new Face(points.get(7),
				points.get(6),
				points.get(2),
				points.get(3),
				this.faceLoc);
		
		
		//white
		 topFace = new Face(
				points.get(0),
				points.get(1),
				points.get(5),
				points.get(4),
				this.faceLoc);
		
		faces.add(bottomFace);
		faces.add(topFace);
		faces.add(frontFace);
		faces.add(backFace);
		faces.add(rightFace);
		faces.add(leftFace);
		
		for(Face f : faces) {
			f.setFaceLoc(faceLoc);
		}
		
	}
	
	
	
	
	

	
	public void rotateXY(double thetaX, double thetaY) {
		for(Point3D p : points) {
			p.rotateX(thetaX);
			p.rotateY(thetaY);
			
		}
	}
		

	public ArrayList<Face> getFaces(){
		return faces;
	}
		
		
	public double furthest() {
		double maxval = 0;
		for(Face f : faces) {
			maxval = Math.max(maxval, f.furthest());
		}
		return maxval;
	}
	
	
	
	
	
	
	@Override
	public int compareTo(Cubie o) {
		// TODO Auto-generated method stub
		if (furthest() > o.furthest()) {
			return 1;
		}else if (furthest() == o.furthest()) {
			return 0;
		}
		return -1;
	}
	
	
	
	
	
	

	


	
}
