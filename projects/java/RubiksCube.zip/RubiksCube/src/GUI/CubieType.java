package GUI;

public enum CubieType {
	FRONT(0), BACK(1), TOP(2), BOTTOM(3), LEFT(4), RIGHT(5);
	
	private int value;
	private CubieType(int value) {
		this.value = value;
	}
	
	public int getValue() {
		return value;
	}
	
	
	
	
}
