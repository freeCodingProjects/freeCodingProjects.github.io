package GUI;

import java.awt.BasicStroke;
import java.awt.Color;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.HashMap;


public class Face implements Comparable<Face>{
	
	Point3D p1,p2,p3,p4;
	int xpoints[];
	int ypoints[];
	int faceColor;
	
	
	/*
	 * Notes to self:
	 * Blue is opposite Green
	 * Yellow opposite White
	 * Orange is opposite Red
	 */
	
	public boolean showGrid;
	public static Color[] colors = new Color[] {
									Color.WHITE,
									Color.yellow,
									Color.RED,
									Color.ORANGE,
									Color.BLUE,
									Color.GREEN,
									Color.BLACK,
									Color.pink
	};
			
	
	
	
	 
	private ArrayList<Point3D> points;
	private int[] faceLoc;
	public Face(Point3D p1, Point3D p2, Point3D p3,Point3D p4, int faceColor) {
		this.p1 = p1;
		this.p2 = p2;
		this.p3 = p3;
		this.p4 = p4;
		showGrid = true;
		faceLoc = new int[] {0,0,0};
		this.faceColor = faceColor;
		points = new ArrayList<Point3D>();
		points.add(p1);points.add(p2);points.add(p3);points.add(p4);
		
		
	}
	public Face(Point3D p1, Point3D p2, Point3D p3,Point3D p4, int[] faceLoc) {
		this(p1,p2,p3,p4);
		this.faceLoc = faceLoc;
		//System.out.println(faceLoc);
		
	}
	
	public Face(Point3D p1, Point3D p2, Point3D p3,Point3D p4) {
		this(p1,p2,p3,p4,6);
	}
	
	public void setFaceLoc(int[] loc) {
		faceLoc = loc;
	}
	
	
	public void setFaceColor(int color) {
		faceColor = color;
	}
	
	public ArrayList<Point3D> getPoints(){
		return points;
	}
	
	

	
	public double furthest() {
		double furthest = p1.distanceFromCamera();
		furthest = Math.max(furthest, p2.distanceFromCamera());
		furthest = Math.max(furthest, p3.distanceFromCamera());
		furthest = Math.max(furthest, p4.distanceFromCamera());
		return furthest;
	}
	
	
	
	public double centerDistance() {
		Point3D c1 = new Point3D();
		c1.x = (p1.x+p3.x)/2;
		c1.y = (p1.y+p3.y)/2;
		c1.z = (p1.z+p3.z)/2;
		Point3D c2 = new Point3D();
		c2.x = (p2.x+p4.x)/2;
		c2.y = (p2.y+p4.y)/2;
		c2.z = (p2.z+p4.z)/2;
		Point3D c3 = new Point3D();
		c3.x = (c1.x+c2.x)/2;
		c3.y = (c1.y+c2.y)/2;
		c3.z = (c1.z+c2.z)/2;
		return c3.norm();
	}

	
	public Point3D getCenter() {
		Point3D c1 = new Point3D();
		c1.x = (p1.x+p3.x)/2;
		c1.y = (p1.y+p3.y)/2;
		c1.z = (p1.z+p3.z)/2;
		Point3D c2 = new Point3D();
		c2.x = (p2.x+p4.x)/2;
		c2.y = (p2.y+p4.y)/2;
		c2.z = (p2.z+p4.z)/2;
		Point3D c3 = new Point3D();
		c3.x = (c1.x+c2.x)/2;
		c3.y = (c1.y+c2.y)/2;
		c3.z = (c1.z+c2.z)/2;
		return c3;
	}

	
	public void paintFace(Graphics g) {
		
		Point2D p12D = p1.projectFromCamera();
		Point2D p22D = p2.projectFromCamera();
		Point2D p32D = p3.projectFromCamera();
		Point2D p42D = p4.projectFromCamera();
		
		ArrayList<Point2D> points2D = new ArrayList<Point2D>();
		points2D.add(p12D);
		points2D.add(p22D);
		points2D.add(p32D);
		points2D.add(p42D);
		
		xpoints = new int[] {
				/*
				p1.projectFromCamera().x,
				p2.projectFromCamera().x,
				p3.projectFromCamera().x,
				p4.projectFromCamera().x,*/
				p12D.x,
				p22D.x,
				p32D.x,
				p42D.x,
				
		};
		
		ypoints = new int[] {
				/*p1.projectFromCamera().y,
				p2.projectFromCamera().y,
				p3.projectFromCamera().y,
				p4.projectFromCamera().y,
				*/
				p12D.y,
				p22D.y,
				p32D.y,
				p42D.y,
		};
		
		g.setColor(colors[faceColor]);
		g.fillPolygon(xpoints, ypoints, 4);
		
		
		
		
		if (faceColor != 6 && showGrid) {
			Graphics2D g2 = (Graphics2D)g;
			g2.setColor(Color.BLACK);
		    g2.setStroke(new BasicStroke(1));
		    drawFaceLoc(g2,p12D,p22D,p32D,p42D);
			//drawOne(g2, p12D, p22D, p32D, p42D, false);
			//drawZero(g2, p12D, p22D, p32D, p42D, true);
		    //drawTwo(g2, p12D, p22D, p32D, p42D, false);
		    //drawZero(g2, p1, p2, p3, p4, true);
		    //drawOne(g2, p1, p2, p3, p4, true);
			
		}
		
		
		
	
	}
	

	/*
	 * This would be considerably better if I could store 
	 * methods in a hashmap
	 */
	private void drawFaceLoc(Graphics2D g2, Point2D p1, Point2D p2, Point2D p3, Point2D p4) {
		boolean flag = false;
		int[] tmp = new int[] {faceLoc[1], faceLoc[2]};
		for(Integer i : tmp) {
			if (i==0) {
				drawZero(g2,p1,p2,p3,p4, flag);
			}else if(i==1) {
				drawOne(g2,p1,p2,p3,p4, flag);
			}else {
				drawTwo(g2,p1,p2,p3,p4, flag);
			}
			
			flag=true;
		}
	}
	
	
	
	
	
	
	/*
	 * Draws a one either left or left of center
	 */
	private void drawOne(Graphics2D g2, Point2D p1, Point2D p2, Point2D p3, Point2D p4, boolean right) {
	    //g2.setStroke(new BasicStroke(2));
		//g2.setColor(Color.BLACK);
		Point2D center = this.getCenter().projectFromCamera();
		
		int y0 = p1.y;
		int y1 = p3.y;
		
		int dy = (p3.y-p1.y)/6;
		int dx = (p4.x-p2.x)/14;
		
	
		y0+=dy;
		y1-=dy;
		
		if (right) {
			center.x+=Math.abs(2*dx);
		}else {
			center.x-=Math.abs(2*dx);
		}
		
	
		
		g2.drawLine(center.x, center.y+dy, center.x, center.y-dy);
		
		
	}
	
	private void drawTwo(Graphics2D g2, Point2D p1, Point2D p2, Point2D p3, Point2D p4, boolean right) {
		Point2D center = this.getCenter().projectFromCamera();
		
		int dy = Math.abs((p3.y-p1.y)/6);
		int dx = -Math.abs((p4.x-p2.x)/6);

		
		if (right) {
			center.x -= dx;
		}else {
			center.x += dx;
		}
		
		g2.drawLine(center.x+dx, center.y-dy, center.x, center.y-dy);
		g2.drawLine(center.x, center.y-dy, center.x, center.y);
		g2.drawLine(center.x, center.y, center.x+dx, center.y);
		g2.drawLine(center.x+dx, center.y, center.x+dx, center.y+dy);
		g2.drawLine(center.x+dx, center.y+dy, center.x, center.y+dy);
		
		
	}
	
	
	private void drawZero(Graphics2D g2, Point2D p1, Point2D p2, Point2D p3, Point2D p4, boolean right) {
		Point2D center = this.getCenter().projectFromCamera();
		
		
		
		int y0 = p1.y;
		int y1 = p3.y;
		
		int dy = (y1-y0)/6;
		int dx = (p4.x-p2.x)/14;
	
		
		if (right) {
			center.x+= Math.abs(2*dx);
		}else {
			center.x-= Math.abs(2*dx);
		}
		

		int[] xpoints = new int[4];
		xpoints[0] = center.x+dx;
		xpoints[1] = center.x-dx;
		xpoints[2] = center.x-dx;
		xpoints[3] = center.x+dx;
		
		int[] ypoints = new int[4];
		ypoints[0] = center.y+dy;
		ypoints[1] = center.y+dy;
		ypoints[2] = center.y-dy;
		ypoints[3] = center.y-dy;
		
		g2.drawPolygon(xpoints,ypoints,4);
		
		
		
		
	}
	
	
	private void drawZero(Graphics2D g2, Point3D p1, Point3D p2, Point3D p3, Point3D p4, boolean right) {
		
		Point3D center = this.getCenter();
		center.x = (center.x+p2.x)/2;
		
		
		
		
		Point2D np1 = new Point3D((center.x+center.x)/2,(center.y+center.y)/2,(center.z+center.z)/2).projectFromCamera();
		Point2D np2 = new Point3D((center.x+center.x)/2,(center.y+center.y)/2,(center.z+center.z)/2).projectFromCamera();
		Point2D np3 = new Point3D((center.x+center.x)/2,(center.y+center.y)/2,(center.z+center.z)/2).projectFromCamera();
		Point2D np4 = new Point3D((center.x+center.x)/2,(center.y+center.y)/2,(center.z+center.z)/2).projectFromCamera();
		
		
		g2.drawLine(np1.x, np1.y, np2.x, np2.y);
		g2.drawLine(np2.x, np2.y, np3.x, np3.y);
		g2.drawLine(np3.x, np3.y, np4.x, np4.y);
		g2.drawLine(np4.x, np4.y, np1.x, np1.y);
		
		
		
		
	}
	private void drawOne(Graphics2D g2, Point3D p1, Point3D p2, Point3D p3, Point3D p4, boolean right) {
		
		Point3D center = this.getCenter();
		double tmp = (center.x+p2.x)/2;
		center.x = center.x + (tmp-p2.x);
		Point2D proj = center.projectFromCamera();
		
		Point2D tmp1 = new Point3D((center.x), (center.y), center.z).projectFromCamera();
		Point2D tmp2 = new Point3D((center.x), (center.y), center.z).projectFromCamera();
		
		//g2.drawLine(tmp1.x, tmp1.y, tmp2.x, tmp2.y);
		//g2.fillOval(tmp1.x, tmp1.y, 5, 5);
		//g2.fillOval(tmp2.x, tmp2.y, 5, 5);
		
		
		
	}
	
	
	
	

	@Override
	public int compareTo(Face o) {
		if (o.furthest() > furthest()) {
			return 1;
		}else if(furthest() == o.furthest()) {
			if (o.faceColor == 6 && faceColor == 6) {
				return 0;
			}
			if (o.faceColor == 6 && faceColor != 6) {
				return 1;
			}
			if (o.faceColor!=6 && faceColor ==6) {
				return -1;
			}
			return 0;
			
			
			
		}
		return -1;
	}
	
	
	
	
}
