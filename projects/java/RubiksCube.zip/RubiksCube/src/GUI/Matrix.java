package GUI;

public class Matrix {
	
	public double[][] matrix;
	private int m;
	private int n;
	public Matrix(int m, int n) {
		this.m = m;
		this.n = n;
		matrix = new double[m][n];
		
	}
	
	
	
	
	public Matrix(double[][] mat) {
		matrix = mat;
		m = mat.length;
		n = mat[0].length;
	}
	
	/*
	 * Lazy transpose
	 */
	public double[][] transpose() {
		double[][] transposed = new double[n][m];
		for(int i =0;i<m;i++) {
			for(int j = 0;j<n;j++) {
				transposed[n][m] = matrix[m][n];
			}
		}
		
		return transposed;
	}
	
	
	public static Point3D toPoint3D(Matrix other) {
		
		Point3D ret = new Point3D(other.matrix[0][0],
							other.matrix[1][0],
							other.matrix[2][0]);
		
		return ret;
	}
	
	

	public double dot(int row, int col, Matrix other) {
		/*
		 * row is matrix[row][:]
		 * col is matrix [:][col]
		 */
		
		double dotProd = 0;
		for(int i =0;i < m; i++) {
			dotProd += matrix[row][i]*other.matrix[i][col];
		}
		
		return dotProd;
	}
	
	
	
	public Matrix matmul(Matrix other) {
		if (this.n != other.m) {
			throw new IllegalArgumentException("Matrices must be (m x n) (n x p)");
		}
		
		//new mat is m x p		
		
		//(1,1) row 1 dot col 1
		//(1,2) row 1 dot col 2
		
		
		
		
		double mat[][] = new double[m][other.n];
		
		for(int row =0; row<m; row++) {
			for(int col = 0; col<other.n; col++) {
				mat[row][col] = dot(row, col, other);
			}
		}
		
		
		return new Matrix(mat);
		
		
	}
	
	
	
	
	public String toString() {
		StringBuffer string = new StringBuffer();
		for(int i =0;i<m;i++) {
			for(int j =0; j<n;j++) {
				string.append(matrix[i][j]+ ", ");	
			}
			string.append("\n");
		}
		string.append("\n");
		return string.toString();
	}
	
	
	
	
}
