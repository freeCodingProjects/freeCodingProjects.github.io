package GUI;

public class Point2D implements Comparable<Point2D>{
	//this is nice i like this
	public int x;
	public int y;
	
	public Point2D(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public Point2D() {
		this(0,0);
	}
	
	
	
	public Point2D grow(int incX, int incY) {
		return new Point2D(x+incX, y+incY);
	}
	
	@Override
	public String toString() {
		return "("+x+", "+y+")";
	}

	@Override
	public int compareTo(Point2D o) {
		// TODO Auto-generated method stub
		if (y>o.y) {
			return 1;
		}else if (y==o.y) {
			return (x>o.x) ? 1:0;
		}
		return -1;
	}
	
	
	@Override
	public boolean equals(Object other) {
		if (!(other instanceof Point2D)) {
			return false;
		}
		Point2D casted = (Point2D)(other);
		
		return casted.x==this.x && casted.y==y;
	}
	
	
	@Override
	public int hashCode() {
		return toString().hashCode();//hopefully unique idk
	}
}
