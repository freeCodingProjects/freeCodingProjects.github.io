package GUI;


public class Point3D {
	public double x;
	public double y;
	public double z;
	
	
	private int offset = 250;
	
	
	

	
	
	public static double cameraX =0;
	public static double cameraY =0;
	public static double cameraZ =3000;
	
	public static double angle = 0.3;
	public static Matrix rotateAboutZ = new Matrix(new double[][] {
		{Math.cos(0), Math.sin(0), 0},
		{-Math.sin(0), Math.cos(0),0},
		{0,0,1}
	});
	public static Matrix rotateAboutY = new Matrix( new double[][] {
		{Math.cos(angle),0,-Math.sin(angle)},
		{0, 1,0},
		{Math.sin(angle),0, Math.cos(angle)}
	});
	public static Matrix rotateAboutX = new Matrix(new double[][] {
			{1., 0.,0.},
			{0., Math.cos(angle/2), Math.sin(angle/2)},
			{0., -Math.sin(angle/2), Math.cos(angle/2)}
	});
	
	public Point3D(double x, double y, double z) {
		this.x = x;
		this.y = y;
		this.z = z;
		
		
	}
	
	
	public Point3D() {
		this(0,0,0);
	}
	
	
	private Matrix toMatrix() {
		return new Matrix(new double[][]{{x},{y},{z}});
	}
	
	
	
	
	
	public void rotateX(double theta) {
		double[][] rotX= new double[][] {
			{1., 0.,0.},
			{0., Math.cos(theta), Math.sin(theta)},
			{0., -Math.sin(theta), Math.cos(theta)}
		};
		Matrix tmp = new Matrix(rotX).matmul(toMatrix());
		this.x = tmp.matrix[0][0];
		this.y = tmp.matrix[1][0];
		this.z = tmp.matrix[2][0];
		//System.out.println(this);
	}
	
	
	
	public void rotateY(double theta) {
		double[][] rotY= new double[][] {
			{Math.cos(theta),0,-Math.sin(theta)},
			{0, 1,0},
			{Math.sin(theta),0, Math.cos(theta)}
		};
		Matrix tmp = new Matrix(rotY).matmul(toMatrix());
		this.x = tmp.matrix[0][0];
		this.y = tmp.matrix[1][0];
		this.z = tmp.matrix[2][0];
		//System.out.println(this);
	}
	
	public void rotateZ(double theta) {
		double[][] rotZ = new double[][] {
			{Math.cos(theta), Math.sin(theta), 0},
			{-Math.sin(theta), Math.cos(theta),0},
			{0,0,1}
		};
		Matrix tmp = new Matrix(rotZ).matmul(toMatrix());
		this.x = tmp.matrix[0][0];
		this.y = tmp.matrix[1][0];
		this.z = tmp.matrix[2][0];
		
	}
	
	/*
	 * Projects From camera position
	 * I'm not loving this, the way i define the display surface just aint correct rn
	 * just gonna call weak projection... left as an excercise to fix haha
	 */
	public Point2D projectFromCamera() {
		/*
		Point3D e = new Point3D(1,1,10);
		Matrix selfMinusCamera = (new Point3D(x-cameraX, y-cameraY, z-cameraZ)).toMatrix();
		Matrix compD = rotateAboutZ.matmul(rotateAboutZ).matmul(rotateAboutZ).matmul(selfMinusCamera);
		Point3D d = Matrix.toPoint3D(compD);
		
		//this is backwards on purpose
		int bx = (int)((20000*(e.z/d.z)*d.x)+200*e.x)+300;
		int by = (int)((20000*(e.z/d.z)*d.y)+200*e.y)+300;
		//System.out.println(bx);
		return new Point2D(bx, by); */
		
		return this.getWeakPersectiveProjection();
	}
	
	

	
	public Point2D getWeakPersectiveProjection() {
		double scalar = 1300/(20-z);
		//scalar=50;
		double projection[][] = new double[][] {
			{scalar,0,0},
			{0,scalar,0}
		};
		Matrix projMat = new Matrix(projection);
		
		Matrix mat = projMat.matmul(this.toMatrix());
		int projX = (int)mat.matrix[0][0]+offset+50;
		int projY = (int)mat.matrix[1][0]+offset;
		Point2D projected = new Point2D(projX, projY);
		return projected;
	}
	
	
	
	
	public int distanceFromCamera() {
		return (int)((Math.pow((x-cameraX),2) + Math.pow((y-cameraY),2)+Math.pow((z-cameraZ),2)));
	}
	
	public double norm() {
		return Math.pow(x,2) + Math.pow(y, 2) + Math.pow(z, 2);
	}
	
	
	
	public void scale(double scale) {
		x*=scale;
		y*=scale;
		z*=scale;
	}
	
	@Override
	public String toString() {
		return "("+x+", "+y+", "+z+")";
	}
	/*
	public static void main(String[] args) {
		ArrayList<Point3D> points = new ArrayList<Point3D>();
		
		points.add(new Point3D(0,0,0));
		points.add(new Point3D(0,0,1));
		points.add(new Point3D(0,1,0));
		points.add(new Point3D(0,1,1));
		points.add(new Point3D(1,0,0));
		points.add(new Point3D(1,0,1));
		points.add(new Point3D(1,1,0));
		points.add(new Point3D(1,1,1));
		
		
		for(int i =0;i<10;i++) {
			for(Point3D p : points) {
				p.rotateY();
				p.rotateX();
				p.rotateZ();
				//p.theta+=0.3;
				System.out.println(p.get2DProjection());
			}
			System.out.println();
		}
		
		
	}*/
	
	
}
