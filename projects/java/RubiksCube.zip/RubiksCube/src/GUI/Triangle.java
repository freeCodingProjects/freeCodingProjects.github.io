package GUI;

import java.awt.Color;
import java.awt.Graphics;

public class Triangle implements Comparable<Triangle>{
	
	Color color;
	Point3D p1, p2,p3;
	public Triangle(Color color, Point3D p1, Point3D p2, Point3D p3) {
		this.color = color;
		this.p1 = p1;
		this.p2 = p2;
		this.p3 = p3;
	}
	
	/*
	 * Rotate points about xy
	 */
	public void rotateXY(double xTheta, double yTheta) {
		p1.rotateX(xTheta);
		p2.rotateX(xTheta);
		p3.rotateX(xTheta);
		
		p1.rotateY(yTheta);
		p2.rotateY(yTheta);
		p3.rotateY(yTheta);
	}
	
	
	int xpoints[] = new int[3];
	int ypoints[] = new int[3];
	public void paintTriangle(Graphics g) {
		Point2D p1Projected = p1.projectFromCamera();
		Point2D p2Projected = p2.projectFromCamera();
		Point2D p3Projected = p3.projectFromCamera();
		
		//kinda weird java doesn't havve a triangle class whatever tho
		g.setColor(color);
		///is this more or less efficient?
		xpoints[0] = p1Projected.x;
		xpoints[1] = p2Projected.x;
		xpoints[2] = p3Projected.x;
		
		ypoints[0] = p1Projected.y;
		ypoints[1] = p2Projected.y;
		ypoints[2] = p3Projected.y;
		
		g.fillPolygon(xpoints, ypoints,3);
		
	}
	
	
	/*
	 * We can short hand this with max - mostly works 
	 */
	public double distance() {
		double maxZ = p1.z;
		maxZ = Math.max(maxZ, p2.z);
		maxZ = Math.max(maxZ, p3.z);
		return maxZ;
	}
	
	
	
	@Override
	public int compareTo(Triangle o) {
		// TODO Auto-generated method stub
		if (o.distance() > distance()) {
			return 1;
		}else if(distance() == o.distance()) {
			if (o.color == Color.black && color == Color.black) {
				return 0;
			}
			if (o.color == Color.black && color != Color.black) {
				return 1;
			}
			if (o.color !=Color.black && color ==Color.black) {
				return -1;
			}
			return 0;
			
			
			
		}
		return -1;
	}

}
