package Student;


import GUI.CubieType;

public class Cube {
	private int cube[][][];
	//initialize cube as 6 by 3 by 3 array and 
	//fill each face (3xby3) with same number as face index
	//i.e cube[0]=[[0,0,0],[0,0,0],[0,0,0]]
	public Cube() {

		
	}

	
	
	
	
	public void rotateTop(boolean clockwise) {
		
	}
	
	public void rotateBottom(boolean clockwise) {
	}
	
	
	
	public int[][] rotateFace(boolean clockwise, int face) {
		/*
		 * example:
		 * [1 2 3]
		 * [4 5 6]
		 * [7 8 9]
		 * 
		 * rotated face
		 * [7 4 1]
		 * [8 5 2]
		 * [9 6 3]
		 * 
		 */
		
		
		
		return new int[][] {{}};
	}
	
	
	public void rotateFront(boolean clockwise) {
		
		
	}
	
	public void rotateBack(boolean clockwise) {
		
	}
	
	
	public void rotateRight(boolean clockwise) {
		
		
		
	}
	
	
	public void rotateLeft(boolean clockwise) {
		
	}
	
	
	/*
	 * This is done for you
	 */
	public int[][][] export6b3by3cube(){
		return cube;
	}
}
